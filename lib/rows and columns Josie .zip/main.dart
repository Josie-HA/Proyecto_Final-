import 'package:flutter/material.dart';
import 'fotitos_code.dart';
import 'package:proy_2023/Small_fotitos.dart';

  void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override

  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi cartelera',
      home: Scaffold(
        /*appBar: AppBar(
          title: Text('Este es mi ejemplo'),
        ),*/
        body: Row  (
          children: [
            Column(
              children: [
                nombre_fotito('https://i.pinimg.com/564x/e8/c3/21/e8c321597ee5c5ed6169c245f4b26574.jpg'),
                nombre_fotito('https://i.pinimg.com/564x/a6/82/26/a682262be1941c62c0746ed496c75742.jpg'),
                nombre_fotito('https://i.pinimg.com/564x/53/4a/97/534a972b08b8f15de5a5f567edb2745b.jpg'),
                nombre_fotito('https://i.pinimg.com/564x/f4/73/51/f47351cbdc3591a058a0216390933c42.jpg'),
              ],
            ),
            Column(
              children: [
                Row(
                  children: [
                    name_fotito('https://i.pinimg.com/564x/53/04/a3/5304a3c9eeda988aec2ab0197ff7463f.jpg'),
                    name_fotito('https://i.pinimg.com/564x/f3/fc/5e/f3fc5e843605346cbefd6f52d2dd743c.jpg'),
                    name_fotito('https://i.pinimg.com/564x/fa/3e/e0/fa3ee0a423b4c51ce091998507f30f1f.jpg'),
                    name_fotito('https://i.pinimg.com/564x/34/72/9c/34729cc15959620a4443bfa2663bb16c.jpg'),
                ],
                ),
                Row(
                  children: [
                  name_fotito('https://i.pinimg.com/564x/00/69/06/0069062612f01c6a3a8686cdf1111712.jpg'),
                  name_fotito('https://www.fashiongonerogue.com/wp-content/uploads/2022/04/Lisa-Blackpink-Celine-2022-Photoshoot02.jpg'),
                  name_fotito('https://i.pinimg.com/564x/cc/48/f3/cc48f3606c4e5cb312ac2996cc3ec53f.jpg'),
                  name_fotito('https://i.pinimg.com/564x/39/e3/53/39e3530c1d587edf8c54efbdc85b4284.jpg'),
                ],
                ),
                Row(
                  children: [
                    name_fotito('https://i.pinimg.com/564x/fb/47/df/fb47df77a142edd620ef06b4fd90b762.jpg'),
                    name_fotito('https://i.pinimg.com/564x/aa/48/36/aa48362520835daaa26550c98d23898d.jpg'),
                    name_fotito('https://i.pinimg.com/564x/0a/97/c9/0a97c9466d5d1b7649a0db91414bc2e9.jpg'),
                    name_fotito('https://i.pinimg.com/564x/bd/5e/7b/bd5e7b2b5c5bac149a24be6c10342b46.jpg'),
                ],
                ),
                Row(
                  children: [
                    name_fotito('https://i.pinimg.com/564x/88/c3/28/88c328c23471f7e3ec2b33816e55f5a5.jpg'),
                    name_fotito('https://i.pinimg.com/564x/05/95/83/059583ba93a1aad3f3efb691f4d77ed2.jpg'),
                    name_fotito('https://i.pinimg.com/564x/66/1b/a0/661ba0d2fed0bd2122ab7b4a36777f0e.jpg'),
                    name_fotito('https://i.pinimg.com/564x/40/79/01/407901526ce3d03a09555e47cd932ad8.jpg'),
                ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
